# Curso-Aplicaciones-ML
Cosas del curso de aplicaciones de machine learning


Para poder correr el código que se muestra aquí tienes que abrirlo en jupyter y tener instaladas las bibliotecas:

numpy
openCV     
matplotlib


Si quieres correr este código en tu python deberás cambiar las funciones de despliegue. Es decir, no usar matplotlib.


Es probable que debas instalar openCV en python 3.5. Para esto, puedes crear un ambiente con python 3.5 en anaconda.
