
# coding: utf-8

# ## OpenCV
# En esta actividad nos familiarizaremos con la biblioteca openCV.
# 
# Objetivos:
# 1. Leer iuna imagen
# 2. Desplegar una imagen con matplotlib
# 3. Aplicar procesamiento a una imagen.
# 4. Guardar una imagen nueva.
# 
# Dra. Jessica Beltrán Márquez

# Lo primero que tenemos que hacer es importar las bibliotecas que vamos a necesitar.
# cv2 - Es la biblioteca openCv
# numpy- Es una biblioteca que se utiliza para realizar operaciones numéricas.
# matplotlib - Es una librería que se utiliza para graficar en jupyter.

# In[2]:


import cv2
import numpy as np
from matplotlib import pyplot as plt
cv2.__version__


# Con cv2.__version__ podemos conocer la versión de openCV que estamos usando

# ## Leer una imagen
# A continuacion leeremos una imagen usando la función imread dentro de openCV. La imagen *dog1* esta almacenada en la carpeta *images*.
# 
# También vamos a mostrar cual es la forma de la imagen (*shape*) usando la función shape.

# In[4]:


img = cv2.imread('./images/dog1.jpg')
imgShape = img.shape
print(imgShape)


# ## Desplegar una imagen
# Ahora vamos a desplegar la imagen utilizando la función *pyplot --> plt* contenidda en la biblioteca matplotlib.
# Nota: Matplotlib utiliza un esquema de colores distinto a RGB (usa BGR), por tal motivo utilizamos la linea img = img[:,:,::-1]. Puedes comentar esta linea usando "#" para ver lo que sucede.  

# In[10]:


img = img[:,:,::-1]   #Esto porque matplotlib utiliza BGR en vez de RGB
plt.imshow(img)     
plt.show()


# ## Aplicar procesamiento a una imagen
# Lo siguiente que haremos es aplicar un filtro llamado filtro Canny. Este filtro requiere recibir la imagen original y 2 valores que corresponden a umbrales. Puedes conocer más de esta función en http://docs.opencv.org/trunk/da/d22/tutorial_py_canny.html
# 
# También vamos a desplegar la imagen original y la imagen con el procesamiento usando la función subplot de matplotlib.

# In[5]:


edgesImg = cv2.Canny(img,100,200)
plt.subplot(121),plt.imshow(img,cmap = 'gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(edgesImg,cmap = 'gray')
plt.title('Edge Image'), plt.xticks([]), plt.yticks([])

plt.show()


# ## Guardar una imagen
# Lo siguiente que haremos será guardar una nueva imagen en la carpeta *images*. Guardaremos la imagen procesada edgesImg.

# In[6]:


cv2.imwrite('./images/dogEdges.jpg',edgesImg)


# Ahora puedes ver en tu carpeta *images* la nueva imagen almacenada.

# ## Más cosas con openCv
# Lo siguiente que haremos es sumar la imagen *dog1* con una nueva imagen *dog2*. Para esto leemos la imagen y revisamos si la forma de ambas imágenes es la misma. Si no es la misma forma, entonces modificamos la forma usando la función *resize*.

# In[7]:


img2 = cv2.imread('./images/dog2.jpg')
img2Shape = img2.shape
print("Forma de la imagen original= ",img2Shape)
img2 = img2[:,:,::-1]   #Esto porque matplotlib utiliza BGR en vez de RGB
plt.imshow(img2)     
plt.show()

img2Resized = cv2.resize(img2, (400, 400))
img2ResizedShape = img2Resized.shape
print("Forma de la imagen despues del resize = ",img2ResizedShape)
plt.imshow(img2Resized)     
plt.show()


# Lo siguiente que hacemos es sumar ambas imágenes y posteriormete desplegarlas.

# In[8]:


imagenMezclada = cv2.add(img,img2Resized)
#imagenMezclada = cv2.addWeighted(img,0.7,img2Resized,0.3,0)
plt.imshow(imagenMezclada)     
plt.show()


# Observa que pasa si descomentas la linea *imagenMezclada = cv2.addWeighted(img,0.7,img2Resized,0.3,0)*  y comentas la linea *imagenMezclada = cv2.add(img,img2Resized)*. Para más información sobre que sucede puedes leer aquí http://docs.opencv.org/3.0-beta/doc/py_tutorials/py_core/py_image_arithmetics/py_image_arithmetics.html#image-arithmetics

# In[ ]:




